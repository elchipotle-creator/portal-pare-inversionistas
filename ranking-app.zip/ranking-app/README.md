# Ranking de inversiones

Página que ordena empresas y ETFs según métricas financieras y tus prioridades. Los datos se descargan solos de Financial Modeling Prep (FMP) cada día hábil. No es asesoría financiera.

## Puesta en marcha (≈15 minutos)

1. **Cuenta y clave.** Crea una cuenta gratuita en financialmodelingprep.com y copia tu clave de API.
2. **Repositorio.** En github.com crea una cuenta y un repositorio nuevo (por ejemplo `mi-ranking`). Para usar GitHub Pages gratis debe ser **público**.
3. **Sube los archivos.** En el repositorio: *Add file → Upload files* y arrastra el contenido de esta carpeta.
   - Si la carpeta oculta `.github` no se sube, crea el archivo a mano: *Add file → Create new file*, escribe `.github/workflows/actualizar.yml` como nombre y pega el contenido del archivo del mismo nombre.
4. **Guarda tu clave como secreto.** *Settings → Secrets and variables → Actions → New repository secret*. Nombre: `FMP_API_KEY`. Valor: tu clave. (Nunca la pegues en un archivo del repositorio.)
5. **Primera descarga.** Pestaña *Actions → Actualizar datos → Run workflow*. Espera a que termine en verde. Si falla, abre la ejecución y lee el mensaje: dice qué símbolo o campo dio problema.
6. **Publica la página.** *Settings → Pages → Deploy from a branch → main / (root) → Save*. En un minuto tendrás tu enlace: `https://TU-USUARIO.github.io/mi-ranking/`.

## Uso diario

- Abre tu enlace: el ranking carga los últimos datos automáticamente.
- Para cambiar qué empresas o ETFs analizas, edita `empresas.txt` y `etfs.txt` (un símbolo por línea) y ejecuta de nuevo *Actualizar datos*.

## Cosas que conviene saber

- **Límite de FMP:** el plan gratuito limita las llamadas por día. Cada empresa o ETF usa 4. Empieza con listas cortas.
- **Datos públicos:** en un repositorio público, cualquiera puede ver tus listas y los JSON descargados. Revisa en los términos de FMP si su plan permite mostrar sus datos públicamente; si no, usa un repositorio privado con un hosting que lo permita (por ejemplo Netlify) o un plan de FMP que lo autorice.
- **Si se detiene:** GitHub puede pausar tareas programadas tras 60 días sin actividad en el repositorio. Basta con ejecutar *Run workflow* una vez.
- **Si una descarga falla**, se conservan los datos anteriores y la página sigue funcionando con ellos.
- **Prueba local (opcional):** `export FMP_API_KEY=...` y `python scripts/fmp_descargar.py AAPL KO` genera un `empresas.json` que puedes cargar con el botón de la página.

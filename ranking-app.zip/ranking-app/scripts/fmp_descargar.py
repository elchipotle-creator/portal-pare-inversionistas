"""Descarga métricas de empresas desde Financial Modeling Prep y genera empresas.json.

Uso:
    pip install requests
    export FMP_API_KEY="tu_clave"        # Windows: set FMP_API_KEY=tu_clave
    python fmp_descargar.py AAPL MSFT KO JNJ XOM

Cada empresa usa 4 llamadas (perfil, métricas TTM, ratios TTM, crecimiento).
El plan gratuito tiene límite diario, así que empieza con pocas empresas.
"""
import json, os, sys, time
import requests

BASE = "https://financialmodelingprep.com/stable"
KEY = os.environ.get("FMP_API_KEY")


def get(endpoint, **params):
    r = requests.get(f"{BASE}/{endpoint}", params={**params, "apikey": KEY}, timeout=30)
    r.raise_for_status()
    data = r.json()
    return data[0] if isinstance(data, list) and data else {}


def pick(d, *names):
    """Devuelve el primer campo existente (los nombres pueden variar entre planes)."""
    for n in names:
        if d.get(n) is not None:
            return d[n]
    return None


def pct(v):
    return None if v is None else round(v * 100, 1)


def num(v, nd=2):
    return None if v is None else round(v, nd)


def empresa(sym):
    perfil = get("profile", symbol=sym)
    km = get("key-metrics-ttm", symbol=sym)
    rt = get("ratios-ttm", symbol=sym)
    gr = get("financial-growth", symbol=sym, limit=1)
    return {
        "n": perfil.get("companyName", sym),
        "s": perfil.get("sector", ""),
        "t": sym,
        "v": {
            "crec": pct(pick(gr, "revenueGrowth")),
            "mar": pct(pick(rt, "netProfitMarginTTM")),
            "roic": pct(pick(km, "returnOnInvestedCapitalTTM", "roicTTM")),
            "deu": num(pick(rt, "debtToEquityRatioTTM", "debtEquityRatioTTM")),
            "fcf": pct(pick(km, "freeCashFlowYieldTTM")),
            "pe": num(pick(rt, "priceToEarningsRatioTTM", "peRatioTTM"), 1),
        },
    }


def main():
    if not KEY:
        sys.exit("Falta la variable de entorno FMP_API_KEY.")
    simbolos = [s.upper() for s in sys.argv[1:]]
    if not simbolos:
        sys.exit("Indica al menos un símbolo, por ejemplo: python fmp_descargar.py AAPL KO")
    salida = []
    for s in simbolos:
        try:
            e = empresa(s)
            faltan = [k for k, v in e["v"].items() if v is None]
            if faltan:
                print(f"{s}: sin datos para {faltan}; se omite.")
                continue
            salida.append(e)
            print(f"{s}: ok")
        except Exception as ex:
            print(f"{s}: error ({ex})")
        time.sleep(0.3)
    with open("empresas.json", "w", encoding="utf-8") as f:
        json.dump(salida, f, ensure_ascii=False, indent=2)
    print(f"Listo: {len(salida)} empresas guardadas en empresas.json")


if __name__ == "__main__":
    main()

"""Descarga métricas de ETFs desde Financial Modeling Prep y genera etfs.json.

Uso:
    pip install requests
    export FMP_API_KEY="tu_clave"        # Windows: set FMP_API_KEY=tu_clave
    python fmp_descargar_etfs.py VOO VT QQQ SCHD BND

Calcula, con precios ajustados por dividendos de los últimos 5 años:
  ret  = rendimiento anualizado (%)
  vol  = volatilidad anualizada (%)
  dd   = caída máxima desde un pico (%, valor negativo)
y obtiene la comisión anual (cost) y el rendimiento por dividendo (div).
Cada ETF usa 4 llamadas a la API.
"""
import json, math, os, statistics, sys, time
from datetime import date, timedelta
import requests

BASE = "https://financialmodelingprep.com/stable"
KEY = os.environ.get("FMP_API_KEY")
ANIOS = 5


def get(endpoint, **params):
    r = requests.get(f"{BASE}/{endpoint}", params={**params, "apikey": KEY}, timeout=30)
    r.raise_for_status()
    return r.json()


def primero(d, *names):
    if isinstance(d, list):
        d = d[0] if d else {}
    for n in names:
        if d.get(n) is not None:
            return d[n]
    return None


def historial(sym):
    hoy = date.today()
    filas = get("historical-price-eod/dividend-adjusted", symbol=sym,
                **{"from": (hoy - timedelta(days=365 * ANIOS + 5)).isoformat(), "to": hoy.isoformat()})
    pts = sorted((f["date"], f.get("adjClose")) for f in filas if f.get("adjClose"))
    return pts


def metricas_precio(pts):
    if len(pts) < 500:
        raise ValueError(f"historial insuficiente ({len(pts)} días); ¿el ETF tiene menos de 2 años?")
    precios = [p for _, p in pts]
    d0, d1 = date.fromisoformat(pts[0][0]), date.fromisoformat(pts[-1][0])
    anios = (d1 - d0).days / 365.25
    ret = (precios[-1] / precios[0]) ** (1 / anios) - 1
    rend = [precios[i] / precios[i - 1] - 1 for i in range(1, len(precios))]
    vol = statistics.stdev(rend) * math.sqrt(252)
    pico, dd = precios[0], 0.0
    for p in precios:
        pico = max(pico, p)
        dd = min(dd, p / pico - 1)
    return round(ret * 100, 1), round(vol * 100, 1), round(dd * 100, 1), round(anios, 1)


def dividendo_anual(sym, precio):
    hace_1a = (date.today() - timedelta(days=365)).isoformat()
    divs = get("dividends", symbol=sym)
    total = sum(d.get("dividend") or d.get("adjDividend") or 0 for d in divs if d.get("date", "") >= hace_1a)
    return round(total / precio * 100, 2) if precio else None


def etf(sym):
    info = get("etf/info", symbol=sym)
    quote = get("quote", symbol=sym)
    pts = historial(sym)
    ret, vol, dd, anios = metricas_precio(pts)
    precio = primero(quote, "price")
    cost = primero(info, "expenseRatio")
    div = dividendo_anual(sym, precio)
    if cost is None or div is None:
        raise ValueError(f"faltan datos (comisión={cost}, dividendo={div})")
    print(f"   {sym}: {anios} años de historial, comisión reportada={cost} (verifica que sea en %)")
    return {
        "n": primero(info, "name") or primero(quote, "name") or sym,
        "s": primero(info, "assetClass") or "ETF",
        "t": sym,
        "v": {"ret": ret, "vol": vol, "dd": dd, "cost": round(float(cost), 3), "div": div},
    }


def main():
    if not KEY:
        sys.exit("Falta la variable de entorno FMP_API_KEY.")
    simbolos = [s.upper() for s in sys.argv[1:]]
    if not simbolos:
        sys.exit("Indica al menos un símbolo, por ejemplo: python fmp_descargar_etfs.py VOO BND")
    salida = []
    for s in simbolos:
        try:
            salida.append(etf(s))
            print(f"{s}: ok")
        except Exception as ex:
            print(f"{s}: se omite ({ex})")
        time.sleep(0.3)
    with open("etfs.json", "w", encoding="utf-8") as f:
        json.dump(salida, f, ensure_ascii=False, indent=2)
    print(f"Listo: {len(salida)} ETFs guardados en etfs.json")


if __name__ == "__main__":
    main()
